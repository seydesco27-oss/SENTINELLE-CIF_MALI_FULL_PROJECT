<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Throwable;

class ClientController extends Controller
{
    /**
     * GET /api/v1/clients
     *
     * Liste paginée des clients avec leur profil AML.
     */
    public function index(Request $request): JsonResponse
    {
        try {
            $query = DB::table('v_customer_aml_profile');

            /*
             * Recherche générale
             */
            if ($request->filled('search')) {
                $search = trim($request->input('search'));

                $query->where(function ($q) use ($search) {
                    $q->where('client_number', 'like', "%{$search}%")
                      ->orWhere('customer_name', 'like', "%{$search}%");
                });
            }

            /*
             * Filtre type client
             *
             * INDIVIDUAL
             * ENTITY
             */
            if ($request->filled('client_type')) {
                $query->where(
                    'client_type',
                    strtoupper(trim($request->input('client_type')))
                );
            }

            /*
             * Filtre niveau de risque
             */
            if ($request->filled('risk_level')) {
                $query->where(
                    'risk_level',
                    strtoupper(trim($request->input('risk_level')))
                );
            }

            /*
             * Filtre PEP
             */
            if ($request->has('is_pep')) {
                $query->where(
                    'is_pep',
                    (int) $request->boolean('is_pep')
                );
            }

            /*
             * Tri
             */
            $allowedSorts = [
                'client_id',
                'client_number',
                'customer_name',
                'client_type',
                'risk_level',
                'risk_score',
                'alert_count',
                'transaction_count',
                'total_volume',
            ];

            $sort = $request->input('sort', 'client_id');

            if (!in_array($sort, $allowedSorts, true)) {
                $sort = 'client_id';
            }

            $direction = strtolower(
                $request->input('direction', 'desc')
            );

            if (!in_array($direction, ['asc', 'desc'], true)) {
                $direction = 'desc';
            }

            $query->orderBy($sort, $direction);

            /*
             * Pagination
             */
            $perPage = min(
                max((int) $request->input('per_page', 20), 1),
                100
            );

            $clients = $query->paginate($perPage);

            return response()->json([
                'success' => true,
                'message' => 'Clients récupérés avec succès.',
                'data' => $clients->items(),
                'meta' => [
                    'current_page' => $clients->currentPage(),
                    'last_page' => $clients->lastPage(),
                    'per_page' => $clients->perPage(),
                    'total' => $clients->total(),
                ],
            ]);

        } catch (Throwable $e) {

            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération des clients.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    /**
     * GET /api/v1/clients/{id}
     *
     * Profil AML complet d'un client.
     */
    public function show(int $id): JsonResponse
    {
        try {

            /*
             * Profil AML principal.
             *
             * Cette vue prend déjà en compte :
             * clients
             * client_individuals
             * client_entities
             * risk_levels
             * accounts
             * transactions
             * alerts
             */
            $profile = DB::table('v_customer_aml_profile')
                ->where('client_id', $id)
                ->first();

            if (!$profile) {
                return response()->json([
                    'success' => false,
                    'message' => 'Client introuvable.',
                ], 404);
            }


            /*
             * Informations individuelles
             */
            $individual = DB::table('client_individuals')
                ->where('client_id', $id)
                ->first();


            /*
             * Informations entreprise / entité
             */
            $entity = DB::table('client_entities')
                ->where('client_id', $id)
                ->first();


            /*
             * Comptes du client
             */
            $accounts = DB::table('accounts')
                ->where('client_id', $id)
                ->orderBy('id')
                ->get();


            /*
             * Alertes du client
             */
            $alerts = DB::table('alerts')
                ->where('client_id', $id)
                ->orderByDesc('created_at')
                ->limit(100)
                ->get();


            /*
             * Transactions du client
             */
            $transactions = DB::table('transactions as t')
                ->join(
                    'accounts as a',
                    'a.id',
                    '=',
                    't.account_id'
                )
                ->where('a.client_id', $id)
                ->select(
                    't.*'
                )
                ->orderByDesc('t.transaction_date')
                ->limit(100)
                ->get();


            /*
             * Score AML détaillé
             */
            $riskScore = DB::table('risk_scores')
                ->where('client_id', $id)
                ->first();


            /*
             * Réponse structurée.
             */
            return response()->json([
                'success' => true,

                'data' => [

                    'profile' => $profile,

                    'individual' => $individual,

                    'entity' => $entity,

                    'accounts' => $accounts,

                    'transactions' => $transactions,

                    'alerts' => $alerts,

                    'risk_score' => $riskScore,
                ],
            ]);

        } catch (Throwable $e) {

            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération du profil client.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}