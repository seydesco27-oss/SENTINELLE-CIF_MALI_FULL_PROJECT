<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Throwable;

class ClientProfileController extends Controller
{
    /**
     * Profil AML complet d'un client.
     *
     * Exploite :
     * - clients
     * - client_individuals
     * - client_entities
     * - client_aliases
     * - identity_documents
     * - beneficial_owners
     * - risk_levels
     * - v_customer_aml_profile
     * - v_ml_customer_features_current
     */
    public function show(int $id): JsonResponse
    {
        try {
            /*
             * =====================================================
             * 1. PROFIL AML SYNTHETIQUE
             * =====================================================
             */

            $amlProfile = DB::table('v_customer_aml_profile')
                ->where('client_id', $id)
                ->first();

            if (!$amlProfile) {
                return response()->json([
                    'success' => false,
                    'message' => 'Client introuvable.',
                    'client_id' => $id,
                ], 404);
            }

            /*
             * =====================================================
             * 2. FEATURES CLIENT + STATISTIQUES
             * =====================================================
             */

            $features = DB::table('v_ml_customer_features_current')
                ->where('client_id', $id)
                ->first();

            /*
             * =====================================================
             * 3. CLIENT DE BASE
             * =====================================================
             */

            $client = DB::table('clients as c')
                ->leftJoin(
                    'risk_levels as rl',
                    'rl.id',
                    '=',
                    'c.risk_level_id'
                )
                ->where('c.id', $id)
                ->select([
                    'c.id',
                    'c.client_number',
                    'c.client_type',
                    'c.status',
                    'c.phone',
                    'c.email',
                    'c.is_pep',
                    'c.risk_level_id',
                    'c.risk_score',
                    'c.created_at',
                    'rl.code as risk_level_code',
                    'rl.label as risk_level_label',
                    'rl.description as risk_level_description',
                ])
                ->first();

            /*
             * =====================================================
             * 4. PROFIL INDIVIDUAL
             * =====================================================
             */

            $individual = DB::table('client_individuals')
                ->where('client_id', $id)
                ->first();

            /*
             * =====================================================
             * 5. PROFIL ENTITY
             * =====================================================
             */

            $entity = DB::table('client_entities')
                ->where('client_id', $id)
                ->first();

            /*
             * =====================================================
             * 6. ALIAS
             * =====================================================
             */

            $aliases = DB::table('client_aliases')
                ->where('client_id', $id)
                ->get();

            /*
             * =====================================================
             * 7. DOCUMENTS D'IDENTITE
             * =====================================================
             */

            $identityDocuments = DB::table('identity_documents')
                ->where('client_id', $id)
                ->get();

            /*
             * =====================================================
             * 8. BENEFICIAL OWNERS
             * =====================================================
             */

            $beneficialOwners = DB::table('beneficial_owners')
                ->where('client_id', $id)
                ->get();

            /*
             * =====================================================
             * 9. REPONSE
             * =====================================================
             */

            return response()->json([
                'success' => true,

                'data' => [
                    'client' => $client,

                    'profile' => [
                        'aml' => $amlProfile,
                        'features' => $features,
                    ],

                    'individual' => $individual,
                    'entity' => $entity,

                    'aliases' => $aliases,

                    'identity_documents' => $identityDocuments,

                    'beneficial_owners' => $beneficialOwners,
                ],
            ]);

        } catch (Throwable $e) {

            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la récupération du profil client.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}